#ifndef TORRETAS_H
#define TORRETAS_H

#include <iostream>

class Torretas {
private:
    int danio_t;
    int hp_t;
    int id_t;
    int num_t;

public:
    Torretas(int danioT, int hpT, int idT, int numT);

    void atacarT();
    void caer();
    void informacionT();

    int getDanio_t() const;
    int getHp_t() const;
    int getId_t() const;
    int getNum_t() const;

    void setDanio_t(int danioT);
    void setHp_t(int hpT);
    void setId_t(int idT);
    void setNum_t(int numT);
};

Torretas::Torretas(int danioT, int hpT, int idT, int numT)
    : danio_t(danioT), hp_t(hpT), id_t(idT), num_t(numT) {}

void Torretas::atacarT() {
    std::cout << "La torreta " << id_t << " hace " << danio_t << " de daño al jugador." << std::endl;
}

void Torretas::caer() {
    std::cout << "La torreta " << id_t << " ha caído cuando poseía " << hp_t << " puntos de vida totales." << std::endl;
}

void Torretas::informacionT() {
    std::cout << "Tiene " << num_t << " torretas las cuales cuentan con " << hp_t << " de vida y hacen " << danio_t << " puntos de daño." << std::endl;
}

int Torretas::getDanio_t() const {
    return danio_t;
}

int Torretas::getHp_t() const {
    return hp_t;
}

int Torretas::getId_t() const {
    return id_t;
}

int Torretas::getNum_t() const {
    return num_t;
}

void Torretas::setDanio_t(int danioT) {
    danio_t = danioT;
}

void Torretas::setHp_t(int hpT) {
    hp_t = hpT;
}

void Torretas::setId_t(int idT) {
    id_t = idT;
}

void Torretas::setNum_t(int numT) {
    num_t = numT;
}
#endif

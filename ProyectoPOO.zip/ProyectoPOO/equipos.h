#ifndef EQUIPOS_H
#define EQUIPOS_H

#include <iostream>
#include <string>
#include "Invocador.h"

class Equipos : public Invocador {
private:
    std::string campeon;
    std::string posicion;
    Invocador& invocador;

public:
    Equipos(std::string camp, std::string pos, Invocador& inv);
    
    void buscar_invocadores();

    std::string getCampeon() const;
    std::string getPosicion() const;
    Invocador& getInvocador() const;

    void setCampeon(std::string camp);
    void setPosicion(std::string pos);
    void setInvocador(Invocador& inv);
};

Equipos::Equipos(std::string camp, std::string pos, Invocador& inv)
    : campeon(camp), posicion(pos), invocador(inv) {}

void Equipos::buscar_invocadores() {
    std::cout << "El invocador " << invocador.getNombre_invocador() << " utilizará al campeón " << campeon << " e irá en la posición " << posicion << "." << std::endl;
}

std::string Equipos::getCampeon() const {
    return campeon;
}

std::string Equipos::getPosicion() const {
    return posicion;
}

Invocador& Equipos::getInvocador() const {
    return invocador;
}

void Equipos::setCampeon(std::string camp) {
    campeon = camp;
}

void Equipos::setPosicion(std::string pos) {
    posicion = pos;
}

void Equipos::setInvocador(Invocador& inv) {
    invocador = inv;
}
#endif

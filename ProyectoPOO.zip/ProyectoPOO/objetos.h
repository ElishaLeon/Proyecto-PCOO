#ifndef OBJETOS_H
#define OBJETOS_H

#include <iostream>
#include <string>

class Objetos {
private:
    std::string tipo_o;
    std::string habilidad_o;
    int costo;

public:
    Objetos(std::string tipoO, std::string habilidadO, int cost);

    void comprar();

    std::string getTipo_o() const;
    std::string getHabilidad_o() const;
    int getCosto() const;

    void setTipo_o(std::string tipoO);
    void setHabilidad_o(std::string HabilidadO);
    void setCosto(int cost);
};

Objetos::Objetos(std::string tipoO, std::string habilidadO, int cost) : tipo_o(tipoO), habilidad_o(habilidadO), costo(cost) {}

void Objetos::comprar() {
    std::cout << "Un invocador ha comprado el objeto " << tipo_o << " al costo de " << costo << " oro, y otorga la habilidad de " << habilidad_o << "." << std::endl;
}

std::string Objetos::getTipo_o() const {
    return tipo_o;
}

std::string Objetos::getHabilidad_o() const {
    return habilidad_o;
}

int Objetos::getCosto() const {
    return costo;
}

void Objetos::setTipo_o(std::string tipoO) {
    tipo_o = tipoO;
}

void Objetos::setHabilidad_o(std::string habilidadO) {
    habilidad_o = habilidadO;
}

void Objetos::setCosto(int cost) {
    costo = cost;
}


#endif

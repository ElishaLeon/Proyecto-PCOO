#ifndef CRIATURAS_H
#define CRIATURAS_H

#include <iostream>
#include <string>

class Criaturas {
private:
    std::string tipo_c;
    std::string nombre_c;
    int hp_c;
    int danio_c;

public:
    Criaturas(std::string tipoC, std::string nombreC, int hpC, int danioC);

    void atacar_jugador();
    void morirC();
    void informacionC();

    std::string getTipo_c() const;
    std::string getNombre_c() const;
    int getHp_c() const;
    int getDanio_c() const;

    void setTipo_c(std::string tipoC);
    void setNombre_c(std::string nombreC);
    void setHp_c(int hpC);
    void setDanio_c(int danioC);
};

Criaturas::Criaturas(std::string tipoC, std::string nombreC, int hpC, int danioC)
    : tipo_c(tipoC), nombre_c(nombreC), hp_c(hpC), danio_c(danioC) {}

void Criaturas::atacar_jugador() {
    std::cout << "La criatura " << nombre_c << " ataca a un invocador." << std::endl;
}

void Criaturas::morirC() {
    std::cout << "El jungla se ha robado a la " << nombre_c << " enemiga, la cual tenía " << hp_c << " puntos de vida." << std::endl;
}

void Criaturas::informacionC() {
    std::cout << "La criatura " << nombre_c << " es de tipo " << tipo_c << ", tiene " << hp_c << " de vida y hace " << danio_c << " puntos de daño." << std::endl;
}

std::string Criaturas::getTipo_c() const {
    return tipo_c;
}

std::string Criaturas::getNombre_c() const {
    return nombre_c;
}

int Criaturas::getHp_c() const {
    return hp_c;
}

int Criaturas::getDanio_c() const {
    return danio_c;
}

void Criaturas::setTipo_c(std::string tipoC) {
    tipo_c = tipoC;
}

void Criaturas::setNombre_c(std::string nombreC) {
    nombre_c = nombreC;
}

void Criaturas::setHp_c(int hpC) {
    hp_c = hpC;
}

void Criaturas::setDanio_c(int danioC) {
    danio_c = danioC;
}

#endif

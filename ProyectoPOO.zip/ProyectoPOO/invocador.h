#ifndef INVOCADOR_H
#define INVOCADOR_H

#include <iostream>
#include <string>

class Invocador {
protected:
    std::string nombre_invocador;
    int nivel;
    int rank;
    int campeones_adquiridos;

public:
    Invocador();
    Invocador(std::string nom_inv, int lvl, int rkn, int num_camp);

    void buscar_partida();
    void reportar();

    std::string getNombre_invocador() const;
    int getNivel() const;
    int getRank() const;
    int getCampeones_adquiridos() const;

    void setNombre_invocador(std::string nom_inv);
    void setNivel(int lvl);
    void setRank(int rnk);
    void setCampeones_adquiridos(int num_camp);
};

Invocador::Invocador() : nombre_invocador(""), nivel(0), rank(0), campeones_adquiridos(0) {}

Invocador::Invocador(std::string nom_inv, int lvl, int rkn, int num_camp)
    : nombre_invocador(nom_inv), nivel(lvl), rank(rkn), campeones_adquiridos(num_camp) {}

void Invocador::buscar_partida() {
    std::cout << "El invocador " << nombre_invocador << " de nivel " << nivel << " tiene " << campeones_adquiridos << " campeones adquiridos y está buscando partida" << std::endl;
}

void Invocador::reportar() {
    std::cout << "El invocador " << nombre_invocador << " desea reportar a un enemigo de rank " << rank << " por ir Yi support troll." << std::endl;
}

std::string Invocador::getNombre_invocador() const {
    return nombre_invocador;
}

int Invocador::getNivel() const {
    return nivel;
}

int Invocador::getRank() const {
    return rank;
}

int Invocador::getCampeones_adquiridos() const {
    return campeones_adquiridos;
}

void Invocador::setNombre_invocador(std::string nom_inv) {
    nombre_invocador = nom_inv;
}

void Invocador::setNivel(int lvl) {
    nivel = lvl;
}

void Invocador::setRank(int rnk) {
    rank = rnk;
}

void Invocador::setCampeones_adquiridos(int num_camp) {
    campeones_adquiridos = num_camp;
}
#endif

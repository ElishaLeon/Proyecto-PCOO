#ifndef MINIONS_H
#define MINIONS_H

#include <iostream>
#include <string>

class Minions {
private:
    std::string tipo_m;
    int hp_m;
    int danio_m;

public:
    Minions(std::string tipoM, int hpM, int danioM);

    void atacar_torreta();
    void soltar_oro();
    void morirM();
    void informacionM();

    std::string getTipo_m() const;
    int getHp_m() const;
    int getdanio_m() const;

    void setTipo_m(std::string tipoM);
    void setHp_m(int hpM);
    void setDanio_m(int danioM);
};

Minions::Minions(std::string tipoM, int hpM, int danioM)
    : tipo_m(tipoM), hp_m(hpM), danio_m(danioM) {}

void Minions::atacar_torreta() {
    std::cout << "Un minion de tipo " << tipo_m << " ataca la torreta de la línea inferior." << std::endl;
}

void Minions::soltar_oro() {
    std::cout << "Un minion tipo " << tipo_m << " hace " << danio_m << " puntos de daño, y suelta 12 de oro." << std::endl;
}

void Minions::morirM() {
    std::cout << "El support se ha robado un minion tipo " << tipo_m << " cuando tenía " << hp_m << " de vida." << std::endl;
}

void Minions::informacionM() {
    std::cout << "El minion " << tipo_m << " tiene " << hp_m << " de vida y hace " << danio_m << " puntos de daño." << std::endl;
}

std::string Minions::getTipo_m() const {
    return tipo_m;
}

int Minions::getHp_m() const {
    return hp_m;
}

int Minions::getdanio_m() const {
    return danio_m;
}

void Minions::setTipo_m(std::string tipoM) {
    tipo_m = tipoM;
}

void Minions::setHp_m(int hpM) {
    hp_m = hpM;
}

void Minions::setDanio_m(int danioM) {
    danio_m = danioM;
}

#endif

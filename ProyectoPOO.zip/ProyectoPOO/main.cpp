#include "Invocador.h"
#include "Equipos.h"
#include "Torretas.h"
#include "Minions.h"
#include "Criaturas.h"
#include "Jugador.h"
#include "Partida.h"
#include "Objetos.h"

#include <iostream>
#include <string>
using namespace std;


int main(){

// Invocadores
    cout <<"---------------------------"<< endl;
    cout <<" Información del Invocador  "<< endl;
    cout <<"---------------------------"<< endl;
    
    Invocador inv1("LuniiBlue", 56, 0, 36);
    Invocador inv2("DanKookie", 445, 4, 97);
    Invocador inv3("RacsoLen", 589, 5, 89);
    Invocador inv4("Un_Coco", 36, 0, 9);
    Invocador inv5("Vinz", 07, 0, 9);

    Invocador inv6("NoobMaster69", 69, 3, 47);
    Invocador inv7("FrankJonesy", 27, 0, 38);
    Invocador inv8("UnPayasO", 143, 1, 39);
    Invocador inv9("Una_Milanesa", 208, 3, 8);
    Invocador inv10("Caramelito", 01, 0, 1);

    inv1.buscar_partida();

    
    cout << endl;

    // Equipos
    cout <<"---------------------------"<< endl;
    cout <<" Creacion del Equipo rojo  "<< endl;
    cout <<"---------------------------"<< endl;

    // Cambios aquí para usar referencias a Invocador
    Equipos e1("Neeko", "Support", inv1);
    Equipos e2("Ezreal", "ADC", inv2);
    Equipos e4("Maestro Yi", "Jungle", inv4);
    Equipos e5("Garen", "Top", inv5);
    Equipos e9("Jax", "Jungle", inv9);

    e1.buscar_invocadores();
    e2.buscar_invocadores();
    e4.buscar_invocadores();
    e5.buscar_invocadores();
    e9.buscar_invocadores();

    cout << endl;

// Partida
    cout <<"-------------------------"<< endl;
    cout <<" Creacion de la Partida"<< endl;
    cout <<"-------------------------"<< endl;
    
    Partida p1("Reclutamiento", "Grieta del Invocador");
    Partida p2("Clasificatoria", "Grieta del Invocador");

    cout << endl;
    p1.iniciar_partida();

    cout << endl;

// Torretas
    cout <<"-----------"<< endl;
    cout <<" Torretas"<< endl;
    cout <<"-----------"<< endl;

    cout << endl;    
    Torretas lamentos(250, 5000, 1, 8);
    Torretas ginvocador(250, 5000, 1, 8);

    lamentos.atacarT();
    ginvocador.caer();

    cout << endl;

// Minions
    cout <<"----------"<< endl;
    cout <<" Minions"<< endl;
    cout <<"----------"<< endl;
    
    
    Minions normal("Normal", 50, 25);
    Minions mago("Mago", 70, 35);
    Minions tanque("Tanque", 350, 60);

    normal.atacar_torreta();
    mago.soltar_oro();
    tanque.morirM();

    cout << endl;

// Criaturas
    cout <<"-----------"<< endl;
    cout <<" Criaturas"<< endl;
    cout <<"-----------"<< endl;
    
    Criaturas c1("Corrupta", "El Heraldo", 8000, 105);
    Criaturas c2("Dragon", "Dragon Infernal", 4000, 86);
    Criaturas c3("Escarabajo", "Criatura de rio", 200, 0);

    c1.atacar_jugador();
    c2.informacionC();
    c3.morirC();


    cout << endl;

// Jugadores_ingame
    cout <<"-----------"<< endl;
    cout <<"Jugadores"<< endl;
    cout <<"-----------"<< endl;
    
    Jugador j1("Xayah",5, 613, 147, 360);
    Jugador j2("Jax",7, 175, 630, 130);
    Jugador j3("Neeko",14, 1400, 850, 1460);
    Jugador j4("Rakan",2, 405, 250, 205);
    Jugador j5("Zoe",16, 2600, 1700, 4795);


    j1.atacar();
    j2.morir();
    j3.tp();

    cout << endl;

// Objetos
    cout <<"-----------"<< endl;
    cout <<" Objetos"<< endl;
    cout <<"-----------"<< endl;
    
    Objetos o1("Varita explosiva","+40 de poder de habilidad", 850);
    Objetos o2("Cuchilla Negra", "+50 de año de ataque, +400 de vida, +30 de velocidad de habilidades", 3000);
    Objetos o3("Hoja del rey arruinado", "+40 de daño de ataque, +25 de velocidad de ataque, +10 de robo de vida",3200 );

    o1.comprar();
    o2.comprar();
    o3.comprar();


    cout << endl;

    cout <<"-------------------------"<< endl;
    cout <<" Final de la Partida"<< endl;
    cout <<"-------------------------"<< endl;

    inv3.reportar();

    return 0;
}
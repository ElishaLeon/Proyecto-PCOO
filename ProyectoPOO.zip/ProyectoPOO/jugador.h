#ifndef JUGADOR_H
#define JUGADOR_H

#include <iostream>
#include "invocador.h"

class Jugador : public Invocador {
private:
    int nivel_j;
    int vida_j;
    int mana_j;
    int Oro_j;

public:
    Jugador(std::string nom_inv, int lvlJ, int hpJ, int manaJ, int oroJ);

    void atacar();
    void morir();
    void tp();

    int getNivel_j() const;
    int getVida_j() const;
    int getMana_j() const;
    int getDinero_j() const;

    void setNivel_j(int lvlJ);
    void setVida_j(int hpJ);
    void setMana_j(int manaJ);
    void setOro_j(int oroJ);
};

Jugador::Jugador(std::string nom_inv, int lvlJ, int hpJ, int manaJ, int oroJ)
    : Invocador(nom_inv, 0, 0, 0), nivel_j(lvlJ), vida_j(hpJ), mana_j(manaJ), Oro_j(oroJ) {}

void Jugador::atacar() {
    std::cout << "El ataque Q del jugador " << nombre_invocador << " en el nivel " << nivel_j << " quita 48 puntos de vida y gasta " << mana_j << " de mana." << std::endl;
}

void Jugador::morir() {
    std::cout << "El jugador " << nombre_invocador << " con " << vida_j << " de vida recibe 235 de daño y muere, ganándole una PENTAKILL al equipo enemigo." << std::endl;
}

void Jugador::tp() {
    std::cout << "El jugador " << nombre_invocador << " ignora la team fight y va a comprar con " << Oro_j << " de oro." << std::endl;
}

int Jugador::getNivel_j() const {
    return nivel_j;
}

int Jugador::getVida_j() const {
    return vida_j;
}

int Jugador::getMana_j() const {
    return mana_j;
}

int Jugador::getDinero_j() const {
    return Oro_j;
}

void Jugador::setNivel_j(int lvlJ) {
    nivel_j = lvlJ;
}

void Jugador::setVida_j(int hpJ) {
    vida_j = hpJ;
}

void Jugador::setMana_j(int manaJ) {
    mana_j = manaJ;
}

void Jugador::setOro_j(int oroJ) {
    Oro_j = oroJ;
}

#endif

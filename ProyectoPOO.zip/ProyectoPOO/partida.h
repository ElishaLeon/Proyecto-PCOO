#ifndef PARTIDA_H
#define PARTIDA_H

#include <iostream>
#include <string>

class Partida {
private:
    std::string tipo_partida;
    std::string mapa;

public:
    Partida(std::string tipo_par, std::string map);

    void iniciar_partida();

    std::string getTipo_partida() const;
    std::string getMapa() const;

    void setTipo_partida(std::string tipo_par);
    void setMapa(std::string map);
};

Partida::Partida(std::string tipo_par, std::string map) : tipo_partida(tipo_par), mapa(map) {}

void Partida::iniciar_partida() {
    std::cout << "Se iniciará una partida " << tipo_partida << " en el mapa " << mapa << "." << std::endl;
}

std::string Partida::getTipo_partida() const {
    return tipo_partida;
}

std::string Partida::getMapa() const {
    return mapa;
}

void Partida::setTipo_partida(std::string tipo_par) {
    tipo_partida = tipo_par;
}

void Partida::setMapa(std::string map) {
    mapa = map;
}

#endif
